 _____________________________________________________________________
| 
|  Excel WBS Master Version 15.0
|  Readme
|
|  May 22, 2026
|_____________________________________________________________________

1. Introduction
Thank you very much for downloading Excel WBS Master.
This program is a tool designed to manage schedules for various projects using Microsoft Excel.


2. About the Software
This Software is shareware.
If a license key is not obtained, the trial period is 14 days from the date you first save the Excel file.


3. Features

At-a-glance Status: 
Plans and actual progress are clearly visible. By entering progress as it happens, the latest status is displayed in an easy-to-understand format. 

Automatic Gantt Chart:
Simply enter dates to display planned and actual schedules as a Gantt chart on the same row. 

Task Dependencies:
Task relationships can be visualized using arrows within the Gantt chart. 

Auto-Drawing Borders:
Borders in the task information area are automatically drawn based on data in the preceding and succeeding rows. 

Flexible Comments:
Since the Gantt chart is drawn using cell formatting, you can freely enter comments or other data into the cells within the chart. 

Long-term Perspectives:
Multiple Gantt chart display functions are available to help grasp project status from a long-term perspective, such as monthly views. 

EVM Charts:
Capability to generate EVM (Earned Value Management) charts and graphs. 

Standard Excel Operations:
No special interface is required; task information can be entered using standard Excel operations. 

Multi-language Support:
The display language supports 10 languages, including Japanese and English. The calendar and day/month displays in the Gantt chart support even more languages. 

Instant Language Switching:
When the language is changed, the screen display updates instantly while preserving all input data.


4. Operating Environment
This Software runs on Microsoft Excel.
Both 32-bit and 64-bit versions of Excel are supported.

Because this program uses macros, Excel macros must be enabled.

Confirmed operating environments:
- Microsoft Excel 2024 (Windows 11)
- Microsoft Excel 2019 (Windows 10)
- Microsoft Excel 2016 (Windows 11)
- Microsoft Office 365 ProPlus (Excel 2002, Windows 10)
- Microsoft 365 Apps for enterprise (Windows 10, 11)


5. License, Terms of Use, Prohibited Actions, Disclaimer
Before using this program, please read the contents of the License_xx.txt file.
It contains information on the license, terms of use, prohibited actions, and disclaimers.
If you do not agree with the contents, please discontinue use of the Software.


6. Installation
Extract the contents of the ExcelWbsMasterVxxx.zip file into any directory and open the Excel file.

Because this program uses macros, please ensure that macro execution is enabled.


7. Uninstallation
No special procedure is required. This software does not use Windows system directories or the registry.


8. Trial Period and License Key
When you open the extracted Excel file for the first time, a dialog will appear showing the trial period and a field to enter a license key. If you have already purchased a license and received a license key file, please select that file. 

The license is purchased per computer on which the software runs. Do not share a single license key file among multiple users or computers. (For details, refer to the License.txt file.) 

If the same file is used on multiple computers, each computer will require a license key input when the Excel file is opened. 

Once the trial period expires, macro-based functions will be disabled until license key authentication is completed. 

The license key dialog can be suppressed via the option settings. In this case, macro functions will be unavailable except on computers where authentication has already been completed. 

Even when macro functions are disabled, general Excel operations such as data editing and saving files remain possible.


9. How to Use
For detailed instructions and usage methods, please refer to the �gUser's Guide�h sheet in the Excel workbook.
Sample input file is also provided. Please refer to it as needed.


10. Contact Information
For inquiries to the author, please refer to the License_xx.txt file included with the Software.
If you encounter program defects, requests, or other issues, feel free to contact the following email address.
I will respond within reasonable limits.
Email: oinouejp@gmail.com

