 _____________________________________________________________________
| 
|  Excel WBS Master Version 16.0
|  Readme
|
|  September 1, 2026
|_____________________________________________________________________

1. Introduction

Thank you very much for downloading Excel WBS Master.
This program is a tool designed to manage schedules for various projects using Microsoft Excel.


2. About the Software

This Software is freeware.


3. Features

At-a-glance Status: 
Plans and actual progress are clearly visible. By entering progress as it happens, the latest status is displayed in an easy-to-understand format. 

Automatic Gantt Chart:
Simply enter dates to display planned and actual schedules as a Gantt chart on the same row. 

Task Dependencies:
Task relationships can be visualized using arrows within the Gantt chart. 

Auto-Drawing Borders:
Borders in the task information area are automatically drawn based on data in the preceding and succeeding rows. 

Flexible Comments:
Since the Gantt chart is drawn using cell formatting, you can freely enter comments or other data into the cells within the chart. 

Long-term Perspectives:
Multiple Gantt chart display functions are available to help grasp project status from a long-term perspective, such as monthly views. 

EVM Charts:
Capability to generate EVM (Earned Value Management) charts and graphs. 

Standard Excel Operations:
No special interface is required; task information can be entered using standard Excel operations. 

Multi-language Support:
The display language supports 10 languages, including Japanese and English. The calendar and day/month displays in the Gantt chart support even more languages. 

Instant Language Switching:
When the language is changed, the screen display updates instantly while preserving all input data.


4. Operating Environment

This Software runs on Microsoft Excel.
Both 32-bit and 64-bit versions of Excel are supported.

Because this program uses macros, Excel macro execution must be enabled.

Confirmed operating environments:
- Microsoft Excel 2024 (Windows 11)
- Microsoft Excel 2019 (Windows 10)
- Microsoft Excel 2016 (Windows 11)
- Microsoft Office 365 ProPlus (Excel 2002, Windows 10)
- Microsoft 365 Apps for enterprise (Windows 10, 11)


5. Copyright

The copyright of the Software belongs entirely to the creator of the Software.
Users may use the Software only in accordance with the terms described herein.


6. Prohibited Actions

- Reverse engineering of the software
Macro code in the Software is password protected.
Reverse engineering by illegal method is prohibited. Code modification is also prohibited.


7. Disclaimer

The Software is provided �gas is,�h without any warranty of quality and performance.
The author of the Software shall not be liable for any direct or indirect damages 
arising from the use of the Software.
The author shall not be responsible for any trouble, loss, or damage resulting from 
the use of the Software.


8. Installation

Extract the contents of the ExcelWbsMasterVxxx.zip file into any directory and open the Excel file.
Because this program uses macros, please ensure that macro execution is enabled.


9. Uninstallation

No special procedure is required. This software does not use Windows system directories or the registry.


10. How to Use

For detailed instructions and usage methods, please refer to the �gUser's Guide�h sheet in the Excel workbook.
Sample input files are also provided. Please refer to them as needed.


11. Contact Information

If you encounter program defects, requests, or other issues, feel free to contact the following email address.
I will respond within reasonable limits.

Email: oinouejp@gmail.com

